System.register([],(function(e,t){"use strict";return{execute:function(){e("R",class{get_erase_size(e,t){return t}})}}}));
